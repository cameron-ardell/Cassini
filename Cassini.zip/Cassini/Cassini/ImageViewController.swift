//
//  ImageViewController.swift
//  Cassini
//
//  Created by Sophia Ardell on 3/3/16.
//  Copyright © 2016 Sophia Ardell. All rights reserved.
//

import UIKit

class ImageViewController: UIViewController {

    //need a model for all of this
    var imageURL: NSURL? {
        didSet {
            //in case already had image
            image = nil
            //wait to see if on screen
            if view.window != nil{
                fetchImage()
            }
        }
    }
    
    private func fetchImage() {
        if let url = imageURL {
            //goes over network - could be slow, fail, etc.
            let imageData = NSData(contentsOfURL: url)
            if imageData != nil {
                //turns bits into an image
                self.image = UIImage(data: imageData!)
            } else {
                image = nil
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(imageView)
        /*if image == nil {
            imageURL = DemoURL.Bowdoin
        }*/
   }
    
    
    override func viewWillAppear(animated: Bool) {
        if image == nil {
            fetchImage()
        }
    }
    
    
    //inserting image programatically
    private var imageView = UIImageView()
    
    private var image : UIImage? {
        get { return imageView.image }
        set {
            imageView.image = newValue
            imageView.sizeToFit()
        }
    }

}
